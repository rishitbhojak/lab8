# your_app/urls.py
from django.contrib import admin
from django.urls import path, include
from . import views
from .views import findbooks
from myapp import views


app_name = 'myapp'

urlpatterns = [
#    path('', views.home, name='home'),  # URL pattern for home
#    path('about/', views.about, name='about'),  # URL pattern for about us
    path('admin/', admin.site.urls),
#    path(r'myapp/', include('myapp.urls1')),
    path('', views.index, name='index'),  # URL pattern for the index view
    path('about/', views.about, name='about'),  # URL pattern for the about view
    path('<int:book_id>/', views.detail, name='detail'),  # URL pattern for the detail view
    path('feedback/', views.getFeedback, name='feedback'),  # URL pattern for the index view
    path('findbooks/', findbooks, name='findbooks'),
    path('place_order/', views.place_order, name='place_order'),
    path('review/', views.review, name='review'),
]
