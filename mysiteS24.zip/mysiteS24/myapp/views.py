# # Create your views here.
# # your_app/views.py
#
# from django.shortcuts import render, get_object_or_404, redirect
# from .forms import FeedbackForm, SearchForm
# from django.http import HttpResponse
# from myapp.models import Book
# from myapp.forms import OrderForm
# from myapp.forms import ReviewForm
#
#
# #def home(request):
# #    return render(request, 'home.html')
#
# #def about(request):
# #    return render(request, 'Aboutus.html')
#
#
# def index(request):
#     booklist = Book.objects.all().order_by('id')[:10]
#     return render(request, 'myapp/index.html', {'booklist': booklist})
#
# def about(request):
#     return render(request, 'myapp/about.html')
#
# def detail(request, book_id):
#     book = get_object_or_404(Book, id=book_id)
#     return render(request, 'myapp/detail.html', {'book': book})
#
# # def getFeedback(request):
# #     if request.method == 'POST':
# #         form = FeedbackForm(request.POST)
# #         if form.is_valid():
# #             feedback = form.cleaned_data['feedback']
# #             if feedback == 'B':
# #                 choice = ' to borrow books.'
# #             elif feedback == 'P':
# #                 choice = ' to purchase books.'
# #             else:
# #                 choice = ' None.'
# #             return render(request, 'myapp/fb_results.html', {'choice': choice})
# #         else:
# #             return HttpResponse('Invalid data')
# #     else:
# #         form = FeedbackForm()
# #         return render(request, 'myapp/feedback.html', {'form': form})
#
# # def findbooks(request):
# #     if request.method == 'POST':
# #         form = SearchForm(request.POST)
# #         if form.is_valid():
# #             name = form.cleaned_data['name']
# #             category = form.cleaned_data['category']
# #             max_price = form.cleaned_data['max_price']
# #             # For now, we'll use a static list of books. Replace this with a database query as needed.
# #             books = {
# #                 'fiction': ['Jane Eyre', 'A Good Story'],
# #                 'science&tech': ['Python Programming', 'Wireless Networks','Advanced Optical Networks'],
# #                 'other': ['Art History'],
# #                 'biography': ['Jane Austen'],
# #                 'travel': ['A New World'],
# #             }
# #             booklist = books.get(category, [])
# #             return render(request, 'myapp/results.html', {'name': name, 'category': category, 'booklist': booklist})
# #         else:
# #             return render(request, 'myapp/findbooks.html', {'form': form, 'error': 'Invalid data'})
# #     else:
# #         form = SearchForm()
# #         return render(request, 'myapp/findbooks.html', {'form': form})
#
#
# def findbooks(request):
#     if request.method == 'POST':
#         form = SearchForm(request.POST)
#         if form.is_valid():
#             name = form.cleaned_data['name']
#             category = form.cleaned_data['category']
#             max_price = form.cleaned_data['max_price']
#
#             if category:
#                 booklist = Book.objects.filter(category=category, price__lte=max_price)
#             else:
#                 booklist = Book.objects.filter(price__lte=max_price)
#
#             print(f"Queried Books: {booklist}")
#
#             return render(request, 'myapp/results.html', {'name': name, 'category': category, 'booklist': booklist})
#         else:
#             return render(request, 'myapp/results.html', {'error': 'Invalid data'})
#     else:
#         form = SearchForm()
#         return render(request, 'myapp/findbooks.html', {'form': form})
#
# def place_order(request):
#     if request.method == 'POST':
#         form = OrderForm(request.POST)
#         if form.is_valid():
#             order = form.save(commit=False)
#             order.save()
#             form.save_m2m()  # Save the many-to-many data for the form.
#             books = order.books.all()
#             member = order.member
#             order_type = order.order_type
#
#             if order_type == 1:  # Assuming 1 is for borrowing
#                 for book in books:
#                     member.borrowed_books.add(book)
#
#             return render(request, 'myapp/order_response.html', {'books': books, 'order': order})
#         else:
#             return render(request, 'myapp/placeorder.html', {'form': form})
#     else:
#         form = OrderForm()
#         return render(request, 'myapp/placeorder.html', {'form': form})
#
# def review(request):
#     if request.method == 'POST':
#         form = ReviewForm(request.POST)
#         if form.is_valid():
#             rating = form.cleaned_data['rating']
#             if 1 <= rating <= 5:
#                 review = form.save()
#                 book = review.book
#                 book.num_reviews += 1
#                 book.save()
#                return redirect('index')  # Adjust this to your actual index view name
#             else:
#                 form.add_error('rating', 'You must enter a rating between 1 and 5!')
#         return render(request, 'myapp/review.html', {'form': form})
#     else:
#         form = ReviewForm()
#         return render(request, 'myapp/review.html', {'form': form})
# def getFeedback(request):
#     if request.method == 'POST':
#         form = FeedbackForm(request.POST)
#         if form.is_valid():
#             selected_choices = form.cleaned_data['choices']
#             return render(request, 'myapp/fb_results.html', {'choices': selected_choices})
#     else:
#         form = FeedbackForm()
#     return render(request, 'myapp/feedback.html', {'form': form})



# Create your views here.
# your_app/views.py

from django.shortcuts import render, get_object_or_404, redirect
from .forms import FeedbackForm, SearchForm
from django.http import HttpResponse
from myapp.models import Book
from myapp.forms import OrderForm, ReviewForm

def index(request):
    booklist = Book.objects.all().order_by('id')[:10]
    return render(request, 'myapp/index.html', {'booklist': booklist})

def about(request):
    return render(request, 'myapp/about.html')

def detail(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    return render(request, 'myapp/detail.html', {'book': book})

def findbooks(request):
    if request.method == 'POST':
        form = SearchForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            category = form.cleaned_data['category']
            max_price = form.cleaned_data['max_price']

            if category:
                booklist = Book.objects.filter(category=category, price__lte=max_price)
            else:
                booklist = Book.objects.filter(price__lte=max_price)

            print(f"Queried Books: {booklist}")

            return render(request, 'myapp/results.html', {'name': name, 'category': category, 'booklist': booklist})
        else:
            return render(request, 'myapp/results.html', {'error': 'Invalid data'})
    else:
        form = SearchForm()
        return render(request, 'myapp/findbooks.html', {'form': form})

def place_order(request):
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            order = form.save(commit=False)
            order.save()
            form.save_m2m()  # Save the many-to-many data for the form.
            books = order.books.all()
            member = order.member
            order_type = order.order_type

            if order_type == 1:  # Assuming 1 is for borrowing
                for book in books:
                    member.borrowed_books.add(book)

            return render(request, 'myapp/order_response.html', {'books': books, 'order': order})
        else:
            return render(request, 'myapp/placeorder.html', {'form': form})
    else:
        form = OrderForm()
        return render(request, 'myapp/placeorder.html', {'form': form})

def review(request):
    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            rating = form.cleaned_data['rating']
            if 1 <= rating <= 5:
                review = form.save()
                book = review.book
                book.num_reviews += 1
                book.save()
                return redirect('myapp:index')  # Adjust this to your actual index view name
            else:
                form.add_error('rating', 'You must enter a rating between 1 and 5!')
        return render(request, 'myapp/review.html', {'form': form})
    else:
        form = ReviewForm()
        return render(request, 'myapp/review.html', {'form': form})

def getFeedback(request):
    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            selected_choices = form.cleaned_data['feedback']
            if selected_choices == 'B':
                selected_choices = 'Borrow'
            elif selected_choices == 'P':
                selected_choices = 'Purchase'
            return render(request, 'myapp/fb_results.html', {'choices': selected_choices})
    else:
        form = FeedbackForm()
    return render(request, 'myapp/feedback.html', {'form': form})
