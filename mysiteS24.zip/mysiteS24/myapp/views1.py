from django.shortcuts import get_object_or_404
from django.http import HttpResponse
from .models import Publisher, Book, Member, Order

# Create your views here.
def index(request):
    response = HttpResponse()
    booklist = Book.objects.all().order_by('id')[:10]
    heading1 = '<p>' + 'List of available books: ' + '</p>'
    response.write(heading1)
    for book in booklist:
        para = '<p>'+ str(book.id) + ': ' + str(book) + '</p>' + str(book.publisher) + str(Publisher.city)
        response.write(para)
    return response

def about(request):
    return HttpResponse("This is an eBook APP.")

def detail(request, book_id):
    book = get_object_or_404(Book, pk=book_id)
    response_text = f"Title: {book.title.upper()}<br>Price: ${book.price}<br>Publisher: {book.publisher.name}"
    response_text = f"Title: {book.price} "
    return HttpResponse(response_text)


def addPub(request):
    return HttpResponse("AddPub page")